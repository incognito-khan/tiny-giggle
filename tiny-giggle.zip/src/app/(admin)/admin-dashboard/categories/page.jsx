import { Category } from '@/components/admin-dashboard/categories/categories';
import React from 'react'

const page = () => {
  return (
    <div className='w-full'>
        <Category />
    </div>
  )
}

export default page;