import { Products } from '@/components/admin-dashboard/products/products';
import React from 'react'

const page = () => {
  return (
    <div className='w-full'>
        <Products />
    </div>
  )
}

export default page;