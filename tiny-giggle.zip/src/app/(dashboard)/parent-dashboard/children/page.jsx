import ChildrenPage from '@/components/parent-dashboard/children/page'
import React from 'react'

const page = () => {
  return (
    <div>
        <ChildrenPage />
    </div>
  )
}

export default page