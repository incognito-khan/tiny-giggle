import Dashboard from '@/components/parent-dashboard/dashboard/dashboard'
import React from 'react'

const page = () => {
  return (
    <div>
        <Dashboard />
    </div>
  )
}

export default page;