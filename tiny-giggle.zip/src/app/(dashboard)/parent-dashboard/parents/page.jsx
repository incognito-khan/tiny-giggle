import ParentsPage from '@/components/parent-dashboard/parent/parents'
import React from 'react'

const page = () => {
  return (
    <div>
        <ParentsPage />
    </div>
  )
}

export default page