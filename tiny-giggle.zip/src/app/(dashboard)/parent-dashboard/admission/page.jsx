import AdmissionsPage from '@/components/parent-dashboard/admission/admission'
import React from 'react'

const page = () => {
  return (
    <div>
        <AdmissionsPage />
    </div>
  )
}

export default page;