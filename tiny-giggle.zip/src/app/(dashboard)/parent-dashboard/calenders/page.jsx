import CalendarPage from '@/components/parent-dashboard/calendars/calendars'
import React from 'react'

const page = () => {
  return (
    <div>
        <CalendarPage />
    </div>
  )
}

export default page