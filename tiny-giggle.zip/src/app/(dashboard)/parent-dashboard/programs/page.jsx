import ProgramsPage from '@/components/parent-dashboard/programs/programs'
import React from 'react'

const page = () => {
  return (
    <div>
        <ProgramsPage />
    </div>
  )
}

export default page