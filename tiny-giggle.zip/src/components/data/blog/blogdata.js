// export const blogPosts = [
//     {
//         id: "1",
//         slug: "baby-school-and-other-secrets",
//         title: "Baby School And Other Secrets",
//         excerpt:
//             "Kids Hised sedauque felis Phasellus gravida lacus quis eros. aenean sapien tornt sed diam classNam efficitur mus morbi eros dictum quam augue ac lacor eet ligero comodo consequat justo duis turpis lorem elit tornt sed diam consectetur.",
//         content: {
//             paragraphs: [
//                 "Kids Hised sedauque felis Phasellus gravida lacus quis eros. aenean sapien tornt sed diam classNam efficitur mus morbi eros dictum quam augue ac lacor eet ligero comodo consequat conse ctetur adipisc ing elit, sed do eiusmod tempor incididunt ut la bore et dolore magna aliqua. Lorem ipsum dolorsit amet contetur adipisc ingelit, sed do eiusmod tempor incidunt.",
//                 "efficitur mus morbi eros dictum quam augue ac lacor eet ligero comodo consequat conse ctetur adipisc ing elit, sed do eiusmod tempor incididunt ut la bore et dolore magna aliqua. Lorem ipsum dolorsit amet contetur adipisc ingelit, sed do eiusmod tempor incidunt.",
//             ],
//             quote: {
//                 text: "Derek Ramsay And Ellen Adna Knwn Thrg Home Secrets Is Can Be Nearly Impossible",
//                 author: "FRENK",
//             },
//             subheading: "School And Other",
//             images: [
//                 "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
//                 "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
//             ],
//         },
//         image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
//         author: "Admin",
//         date: "26. September 2025",
//         category: "Kindergarten",
//         tags: ["Kids", "Academy", "Business", "Class"],
//         readTime: "5 min read",
//     },
//     {
//         id: "2",
//         slug: "couldnt-help-but-splurge-these",
//         title: "Couldn't Help But Splurge These",
//         excerpt:
//             "Kids Hised sedauque felis Phasellus gravida lacus quis eros. aenean sapien tornt sed diam classNam efficitur mus morbi eros dictum quam augue ac lacor eet ligero comodo consequat justo duis turpis lorem elit tornt sed diam consectetur.",
//         content: {
//             paragraphs: [
//                 "Exploring the world of children's education through creative activities and engaging learning experiences. Our approach focuses on hands-on learning that makes education both fun and effective for young minds.",
//                 "Through carefully designed programs, we ensure that every child gets the opportunity to explore their creativity while building essential skills for their future academic journey.",
//             ],
//             quote: {
//                 text: "Education is the most powerful weapon which you can use to change the world",
//                 author: "NELSON MANDELA",
//             },
//             subheading: "Creative Learning Approach",
//             images: [
//                 "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
//                 "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
//             ],
//         },
//         image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
//         author: "Admin",
//         date: "26. September 2025",
//         category: "Kindergarten",
//         tags: ["Cooking", "Learning", "Kids", "Education"],
//         readTime: "4 min read",
//     },
//     {
//         id: "3",
//         slug: "steps-for-choosing-earning",
//         title: "Steps For Choosing To Earning",
//         excerpt:
//             "A comprehensive guide to help parents choose the right educational path for their children's future success and development.",
//         content: {
//             paragraphs: [
//                 "Choosing the right educational approach for your child is one of the most important decisions you'll make as a parent. It sets the foundation for their future learning and development.",
//                 "Our structured approach helps parents understand the various options available and make informed decisions based on their child's unique needs and interests.",
//             ],
//             quote: {
//                 text: "Every child is gifted, they just unwrap their packages at different times",
//                 author: "UNKNOWN",
//             },
//             subheading: "Making the Right Choice",
//             images: [
//                 "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
//                 "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
//             ],
//         },
//         image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
//         author: "Admin",
//         date: "28. September 2025",
//         category: "Education",
//         tags: ["Planning", "Education", "Parents", "Guide"],
//         readTime: "6 min read",
//     },
// ]

// export const recentPosts = [
//     {
//         id: "1",
//         title: "Baby's School And Secrets",
//         date: "APRIL 27, 2025",
//         image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
//         slug: "baby-school-and-other-secrets",
//     },
//     {
//         id: "2",
//         title: "Steps For Choosing To Earning",
//         date: "APRIL 28, 2025",
//         image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
//         slug: "steps-for-choosing-earning",
//     },
//     {
//         id: "3",
//         title: "Father's Day Sunda & Shaving!",
//         date: "APRIL 29, 2025",
//         image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
//         slug: "fathers-day-special",
//     },
// ]

// export const comments = [
//     {
//         id: 1,
//         name: "Sam Walker",
//         date: "APRIL 14,2025",
//         content: "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
//         img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-2.png",
//         replies: [
//             {
//                 id: 2,
//                 name: "Emily Blunt",
//                 date: "APRIL 15,2025",
//                 content: "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
//                 img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-1.png"
//             },
//             {
//                 id: 3,
//                 name: "Tom Hardy",
//                 date: "APRIL 16,2025",
//                 content: "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
//                 img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-1.png"
//             }
//         ]
//     },
//     {
//         id: 4,
//         name: "John Bavuma",
//         date: "MAY 23,2025",
//         content: "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
//         img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-2.png",
//         replies: []
//     }
// ];


// export function getComments() {
//     return comments;
// }

// export function getBlogPost(id) {
//     return blogPosts.find((post) => post.id === id)
// }

// export function getAllBlogPosts() {
//     return blogPosts
// }

// blogData.js

export const blogPosts = [
    {
      id: "1",
      slug: "baby-school-and-other-secrets",
      title: "Baby School and Other Secrets",
      excerpt:
        "Simple, playful routines and small daily activities can make a huge difference in early development. Discover practical tips to help your child grow confident and curious.",
      content: {
        paragraphs: [
          "Small daily routines and playful learning activities lay the foundation for long-term development. Simple games, short story times, and consistent nap schedules help children feel secure while building language and social skills.",
          "At Tiny Giggle we combine guided play with gentle structure — so children learn through exploration, repetition, and warm encouragement. These moments build memory, focus, and early problem-solving abilities.",
        ],
        quote: {
          text: "Caring for a child is a series of small, meaningful moments that grow into lasting confidence.",
          author: "Tiny Giggle Team",
        },
        subheading: "School and Everyday Secrets",
        images: [
          "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
          "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
        ],
      },
      image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
      author: "Tiny Giggle Admin",
      date: "July 28, 2025",
      category: "Kindergarten",
      tags: ["Kids", "Academy", "Parenting", "Routine"],
      readTime: "5 min read",
    },
    {
      id: "2",
      slug: "couldnt-help-but-splurge-these",
      title: "Couldn't Help But Splurge These",
      excerpt:
        "Creative, hands-on activities help children explore the world and develop essential skills. Here are easy-at-home ideas that spark curiosity and play.",
      content: {
        paragraphs: [
          "Hands-on creative activities encourage children to experiment and solve problems in playful ways. From simple crafts to sensory stations, these experiences strengthen fine motor control and imaginative thinking.",
          "When activities are repeated with small variations, children learn cause-and-effect while building confidence. Encouragement and shared attention from caregivers make each activity more meaningful.",
        ],
        quote: {
          text: "Education that engages the heart and hands creates lifelong learners.",
          author: "Early Years Specialist",
        },
        subheading: "Creative Learning Approach",
        images: [
          "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
          "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
        ],
      },
      image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
      author: "Tiny Giggle Team",
      date: "August 01, 2025",
      category: "Kindergarten",
      tags: ["Cooking", "Learning", "Kids", "Creativity"],
      readTime: "4 min read",
    },
    {
      id: "3",
      slug: "steps-for-choosing-earning",
      title: "Steps for Choosing the Right Early Program",
      excerpt:
        "Choosing the right early education path can feel overwhelming. This guide breaks down practical steps to match your child’s needs and family priorities.",
      content: {
        paragraphs: [
          "Selecting an early program should consider the child’s temperament, the learning approach, and the level of parent involvement you prefer. Visit, observe, and ask about daily routines and teacher-child ratios.",
          "Look for settings that balance free play with guided activities, provide warm caregiving, and share regular progress updates—these features support healthy development and strong parent-teacher partnerships.",
        ],
        quote: {
          text: "Every child grows at their own pace — the right environment helps them thrive.",
          author: "Early Years Consultant",
        },
        subheading: "Making the Right Choice",
        images: [
          "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
          "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
        ],
      },
      image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
      author: "Admin",
      date: "July 15, 2025",
      category: "Education",
      tags: ["Planning", "Education", "Parents", "Guide"],
      readTime: "6 min read",
    },
  ];
  
  export const recentPosts = [
    {
      id: "1",
      title: "Baby's School and Secrets",
      date: "APRIL 27, 2025",
      image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
      slug: "baby-school-and-other-secrets",
    },
    {
      id: "2",
      title: "Steps for Choosing the Right Program",
      date: "APRIL 28, 2025",
      image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-2.jpg",
      slug: "steps-for-choosing-earning",
    },
    {
      id: "3",
      title: "Father's Day Special",
      date: "APRIL 29, 2025",
      image: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/vs-blog-b1-1.jpg",
      slug: "fathers-day-special",
    },
  ];
  
  // Comments kept exactly as provided (unchanged)
  export const comments = [
    {
      id: 1,
      name: "Sam Walker",
      date: "APRIL 14,2025",
      content:
        "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
      img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-2.png",
      replies: [
        {
          id: 2,
          name: "Emily Blunt",
          date: "APRIL 15,2025",
          content:
            "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
          img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-1.png",
        },
        {
          id: 3,
          name: "Tom Hardy",
          date: "APRIL 16,2025",
          content:
            "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
          img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-1.png",
        },
      ],
    },
    {
      id: 4,
      name: "John Bavuma",
      date: "MAY 23,2025",
      content:
        "consectetur adipisc ing elits dictum quam augue ac laor eet liglero comiodo conseqatcoe ctetur adipisc ing elit, sed do eiusmod",
      img: "https://html.vecurosoft.com/toddly/demo/assets/img/blog/comment-author-2.png",
      replies: [],
    },
  ];
  
  export function getComments() {
    return comments;
  }
  
  export function getBlogPost(id) {
    return blogPosts.find((post) => post.id === id);
  }
  
  export function getAllBlogPosts() {
    return blogPosts;
  }
  